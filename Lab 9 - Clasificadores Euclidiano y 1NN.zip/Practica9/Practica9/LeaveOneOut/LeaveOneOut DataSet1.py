import numpy as np
import pandas as pd
from sklearn.model_selection import LeaveOneOut     # Libreria para implementación de método LOO
from sklearn.metrics import accuracy_score, confusion_matrix
from scipy.spatial import distance

file_path = 'C:/Users/marco/Downloads/iris/iris.data'

column_names = ["sepal_length", "sepal_width", "petal_length", "petal_width", "class"]
data = pd.read_csv(file_path, header=None, names=column_names)

data.dropna(inplace=True)

X = data.iloc[:, :-1].values
y = data.iloc[:, -1].values

def knn_classifier(X_train, y_train, X_test):
    predictions = []
    for test_point in X_test:
        distances = [distance.euclidean(test_point, train_point) for train_point in X_train]
        nearest_index = np.argmin(distances)
        predictions.append(y_train[nearest_index])
    return np.array(predictions)

# Implementación de Leave-One-Out Cross Validation
loo = LeaveOneOut()

accuracies = []
all_y_true = []  # Lista para almacenar las etiquetas verdaderas
all_y_pred = []  # Lista para almacenar las etiquetas predichas

for train_index, test_index in loo.split(X):  # Leave one out una muestra de test por iteración
    # Dividir el dataset en conjunto de entrenamiento y prueba según los indices en cada iteración 
    X_train, X_test = X[train_index], X[test_index]
    y_train, y_test = y[train_index], y[test_index]
    
    X_test = X_test.reshape(1, -1)  # Convierte X_test a un array 2D de forma (1, n_features)
    
    y_pred = knn_classifier(X_train, y_train, X_test)
    
    # Calcular el Accuracy y guardar las etiquetas verdaderas y predichas
    accuracy = accuracy_score(y_test, y_pred)
    accuracies.append(accuracy)
    
    # Almacenar las etiquetas verdaderas y las predicciones para la matriz de confusión
    all_y_true.extend(y_test)
    all_y_pred.extend(y_pred)

mean_accuracy = np.mean(accuracies)
print(f"Accuracy promedio en Leave-One-Out: {mean_accuracy:.2f}")

total_conf_matrix = confusion_matrix(all_y_true, all_y_pred)
print("Matriz de Confusión total:")
print(total_conf_matrix)
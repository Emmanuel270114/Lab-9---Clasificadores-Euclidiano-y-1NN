import numpy as np      # Librería para cálculo numérico de matrices y vectores  
import pandas as pd     # Libreriía de análisis de datos. Trabajar con hojas de cálculo
from sklearn.model_selection import train_test_split        # Dividir un conjunto de datos, para el método Hold - Out
from sklearn.metrics import accuracy_score, confusion_matrix    # Cálculo del accuracy y la matriz de confusión
from scipy.spatial import distance      # Cálculo de distancias, para la distancia Euclidiana 

# Cargar dataset desde el archivo .data
file_path = 'C:/Users/marco/Downloads/iris/iris.data' 

# Cargar el archivo .data sin encabezados, y asumir que la última columna es la clase
column_names = ["sepal_length", "sepal_width", "petal_length", "petal_width", "class"] # Nombre de columnas del dataset
data = pd.read_csv(file_path, header=None, names=column_names) # Lectura del archivo con panda y convertir en DataFrame, sin encabezados 

data.dropna(inplace=True) # Eliminar fila que tenga valores NaN, es decir, vacios. Modifica el dataframe

# Separar las características (X) y las etiquetas (y)
X = data.iloc[:, :-1].values    # Todas las columnas excepto la ultima, que pertenece a la clase. Convierte en array 
y = data.iloc[:, -1].values     # Etiquetas, solo la ultima columna. Convierte en array 

# Dividir el dataset en 70% para entrenamiento y 30% para prueba
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42) # Random para ser reproducible 

# Función para predecir la clase de un punto del data set con 1-NN
def knn_classifier(X_train, y_train, X_test): # Conjunto de entrenamiento y conjunto de validación
    predictions = []        # Lista para almacenar predicciones 
    for test_point in X_test:
        distances = [distance.euclidean(test_point, train_point) for train_point in X_train]    # Cálculo de distancie euclidiana y el set de entrenamiento
        nearest_index = np.argmin(distances) # Índice del punto de entrenamiento que esta proximo 
        predictions.append(y_train[nearest_index])  # Usar el punto mas cercano para obtener clase
    return np.array(predictions)

# Predecir las clases en el set de entrenamiento y el set de validación 
y_pred = knn_classifier(X_train, y_train, X_test)

# Cálculo del Accuracy
accuracy = accuracy_score(y_test, y_pred)   # Función de sklearn con las clases del conjunto de entrenamiento y las predichas 
print(f"Accuracy: {accuracy:.2f}")

# Matriz de confusión
conf_matrix = confusion_matrix(y_test, y_pred)  # Función de sklearn para crear la matriz de confusión
print("Matriz de Confusión:")
print(conf_matrix)

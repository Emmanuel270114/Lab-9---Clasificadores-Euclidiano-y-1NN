import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix
from scipy.spatial import distance

# Carga el archivo dataset Wheat Seed
file_path = 'C:/Users/marco/Downloads/seeds_dataset.txt' 

column_names = [
    "Area", "Perimeter", "Compactness", "Length_of_kernel", "Width_of_kernel",
    "Asymmetry_coefficient", "Length_of_kernel_groove", "Class"
]

data = pd.read_csv(file_path, header=None, names=column_names, delimiter='\t')

data = data.apply(pd.to_numeric, errors='coerce')

data.dropna(inplace=True)

print(data.head())

X = data.iloc[:, :-1].values  
y = data.iloc[:, -1].values   

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

def knn_classifier(X_train, y_train, X_test):
    predictions = []
    for test_point in X_test:
        distances = [distance.euclidean(test_point, train_point) for train_point in X_train]
        nearest_index = np.argmin(distances)
        predictions.append(y_train[nearest_index])
    return np.array(predictions)

y_pred = knn_classifier(X_train, y_train, X_test)

accuracy = accuracy_score(y_test, y_pred)
print(f"Accuracy: {accuracy:.2f}")

conf_matrix = confusion_matrix(y_test, y_pred)
print("Matriz de Confusión:")
print(conf_matrix)
